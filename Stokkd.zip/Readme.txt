*** Code

Update connection string details in source code (web.config) to the local STOKKD_INV_DEV database on your machine before running.

When making database changes, there is a database project called Stokkd.Database, which tracks the DB schema.
If you make changes in your local database, you can open and run the STOKKD_INV_DEV to DB.scmp comparison to update the database schema in the project to commit to version control.


*** App Login

When running Stokkd use these login details for the backend admin area of the application:

Login: admin@stokkd.com
Pwd: test1234

And these login details for the frontend user area of the application.

Login: developer@stokkd.com
Pwd: test1234

Feel free to change this to your own email address if you want, in the User table.


*** Version Control

When you start a feature, create a feature branch off the develop branch to do the task/project.
Then create a pull request for Matt (matthew@interthread.com.au) to review the code, and have it merged back in to the develop branch.
Initially you will not have access to write directly to the develop branch.